# Razor Barbearia — página da bio

Arquivos:
- `index.html` — página principal
- `assets/barbearia.jpg` — foto de fundo
- `assets/logo-razor.jpg` — logo

## Publicar gratuitamente no GitHub Pages

1. Crie um repositório público no GitHub.
2. Envie `index.html` e a pasta `assets`.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.

Os botões já estão configurados para:
- Christian: +55 51 99520-0126
- Razor Barbearia: +55 51 99399-7046
